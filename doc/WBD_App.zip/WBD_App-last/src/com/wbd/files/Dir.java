/************************************************************************************************************************************/
/** @file		Dir.java
 * 	@brief		WorkByDay check and update for directories
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer
 * 	@created	1/10/21
 * 	@last rev	1/10/21
 *
 * 	@section	Opens
 * 		� none listed
 * 		
 * 	@section	Legal Disclaimer
 * 		2021� Year Company Name, All rights reserved. All contents of this source file and/or any other related source  
 *		files are the explicit property of Justin Reina. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
package com.wbd.files;
import java.io.File;


public class Dir {


	/********************************************************************************************************************************/
	/**	@fcn		public static void create(String name)
	 *  @brief		Create a new filesystem directory
	 *  @details	x
	 *
	 *  @param		[in] (String) name - name for new directory
	 *  
	 *  @section 	Opens
	 *  	get working (currently just plops at proj root)
	 *  
	 *	@section 	Reference
	 *		1. www.tutorialspoint.com/how-to-create-a-new-directory-by-using-file-object-in-java
	 */
	/********************************************************************************************************************************/	
	public static void create(String name) {
		
	//Locals
	boolean bool;
	
	//Creating a File object
	File file = new File(name);
	  
	//Creating the directory
	bool = file.mkdir();
	 
	if(bool){
		System.out.println("Directory created successfully");
	}else{
		System.out.println("Sorry couldn�t create specified directory");	
	}
	
	return;
	}
	
}
